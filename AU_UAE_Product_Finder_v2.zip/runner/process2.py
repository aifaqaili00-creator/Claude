"""Turn a Black Box niche/gap scan CSV into a scored Excel workbook and dashboard documents.
Usage: python3 process2.py <scan.csv> <req.json> <out_dir>
req.json: {"id","kind","phrase","at","date","info":{"AU":{...},"AE":{...}}} (info comes from the scan's save step)
Writes in out_dir: the .xlsx, au_doc.json, ae_doc.json (tab 2), scan_doc.json (tab 3); prints a JSON summary."""
import sys, re, json, time, datetime
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

csv_path, req_path, out = sys.argv[1], sys.argv[2], sys.argv[3]
req = json.load(open(req_path))
rid = re.sub(r'[^A-Za-z0-9-]', '', str(req.get('id', 'x')))[:40]
kind = 'niche' if req.get('kind') == 'niche' else 'gap'
phrase = re.sub(r"[^A-Za-z0-9 &+'-]", ' ', str(req.get('phrase') or ''))[:60].strip()
date = req.get('date') or datetime.date.today().isoformat()
info = req.get('info') or {}
now = int(time.time() * 1000)
at = int(req.get('at') or now)

first = open(csv_path, encoding='utf-8-sig').readline()
if first.startswith('#info '):
    try: info = json.loads(first[6:]) or info
    except Exception: pass
df = pd.read_csv(csv_path, encoding='utf-8-sig', skiprows=1 if first.startswith('#') else 0)
for c in ['title', 'brand', 'category', 'subcategory', 'asin', 'amazon_sells', 'found_by', 'same_niche', 'seller_country', 'fulfillment']:
    if c not in df.columns: df[c] = ''
    df[c] = df[c].fillna('').astype(str)
for c in ['price', 'monthly_sales', 'monthly_revenue', 'reviews', 'rating', 'sellers', 'age_months', 'variations', 'weight_lb']:
    df[c] = pd.to_numeric(df[c], errors='coerce')
for c in ['price', 'monthly_sales', 'monthly_revenue', 'reviews', 'rating', 'sellers', 'age_months', 'variations']:
    df[c] = df[c].fillna(0)

SK = re.compile(r'\b(food|treats?|snacks?|chews?|jerky|flea|tick|supplements?|vitamins?|tablets?|medicine|nappies|wipes|shampoo|litter|cleaning solution|cleaner|detergent|sanitiser|sanitizer|spray|solution|bacteriostatic|pee pads|disposable|candles?|diffuser|bully|medallions|pouch|gel[ée]e|paint|varnish|markers?|plates|wood shavings|gravel|filters?|bags? for|incense)\b', re.I)
EL = re.compile(r'\b(heater|heated|heating|electric|electrical|rechargeable|usb|battery|charger|plug|led|lamp|light up|bluetooth|smart|wifi|motor|blender|kettle|fryer|vacuum|steamer|steam iron|stimulator|tens|ems|thermostat|alarm clock|power ?board|socket|tracker|warmer|humidifier|recorder|label printer|faucet|torch|flashlight|fountain)\b', re.I)
KD = re.compile(r'\b(kids?|children|child|baby|toddler|girls|boys|youth)\b', re.I)
BR = re.compile(r'(spare parts|pop mart|air up|compatible|replacement|dyson|ecovacs|roborock|dreame|shark|kitchen ?aid|tineco|fitbit|whoop)', re.I)
BIG = re.compile(r'^(stanley|owala|spalding|sherrin|franklin|gilbert|steeden|kenwood|black\+decker|lodge|thermos|oxo|keepcup|faber-castell|schneider|liquitex|brother|maxwell|tontine|pyrolux|avanti|bakemaster|olight|inaba|furi|elemental|made by fressko|pizuna|luxor|cooper|yeti|hydro flask|contigo|frank green)', re.I)
TG = {'AU': (100, 230), 'AE': (100, 115)}

def issues(r):
    f = []
    if SK.search(r.title): f.append('consumable/chemical')
    if EL.search(r.title): f.append('electrical')
    if KD.search(r.title): f.append('kids rules')
    if BR.search(r.title): f.append('fits another brand')
    if BIG.search(r.brand): f.append('big brand')
    if r.amazon_sells == 'yes': f.append('Amazon sells')
    if r.variations > 20: f.append('%d variations' % r.variations)
    if r.weight_lb == r.weight_lb and r.weight_lb > 10: f.append('heavy/bulky')
    return ', '.join(f)

if len(df):
    df['issues'] = df.apply(issues, axis=1)
    df['sweet'] = df.apply(lambda r: r.monthly_sales >= TG[r.market][0] and r.reviews <= TG[r.market][1], axis=1)
    df['score'] = (df.monthly_sales / (df.reviews + 20) ** 0.5 * df.age_months.apply(lambda a: 1.15 if 0 < a <= 12 else 1) * df.rating.apply(lambda s: 1.1 if 0 < s <= 4.2 else 1)).round(1)
    df['verdict'] = df.apply(lambda r: ('Good pick' if r.issues == '' else 'Check first') if r.sweet else ('Close' if r.issues == '' and r.monthly_sales >= 50 else 'Skip'), axis=1)
else:
    for c in ['issues', 'sweet', 'score', 'verdict']: df[c] = []
ORDER = {'Good pick': 0, 'Check first': 1, 'Close': 2, 'Skip': 3}
CN = {'AU': 'Australia', 'AE': 'UAE'}
DOM = {'AU': 'amazon.com.au', 'AE': 'amazon.ae'}
CUR = {'AU': 'A$', 'AE': 'AED'}

def leafname(mk):
    i = info.get(mk) or {}
    names = i.get('nicheNames') or []
    return names[-1] if names else (i.get('niche') or 'all safe categories')

title_bits = phrase if kind == 'niche' else 'biggest gap'
label_day = datetime.date.fromisoformat(date).strftime('%-d %b')
slug = re.sub(r'[^A-Za-z0-9]+', '_', title_bits).strip('_')[:40] or 'scan'
xname = 'Black_Box_%s_%s_%s.xlsx' % ('niche' if kind == 'niche' else 'gap', slug, date)
shown_file = req.get('csvfile') if req.get('noexcel') else xname

# ---- Excel ----
F = 'Arial'
wb = Workbook()
hdr, fill = Font(name=F, bold=True, color='FFFFFF'), PatternFill('solid', fgColor='1F4FD6')
VF = {'Good pick': 'E3F4E3', 'Check first': 'FDF1D6', 'Close': 'ECEEED', 'Skip': 'F8E1E1'}
COLS = [('Verdict', 'verdict', 12), ('Same niche', 'same_niche', 9), ('Product title', 'title', 60), ('Brand', 'brand', 16), ('Category', 'category', 18), ('Subcategory', 'subcategory', 22), ('Price', 'price', 9), ('Sales/mo', 'monthly_sales', 9), ('Revenue/mo', 'REV', 11), ('Reviews', 'reviews', 8), ('Rating', 'rating', 7), ('Sellers', 'sellers', 7), ('Age (mo)', 'age_months', 8), ('Variations', 'variations', 9), ('Weight lb', 'weight_lb', 9), ('Score', 'SCORE', 8), ('Watch out', 'issues', 28), ('Found by', 'found_by', 18), ('ASIN', 'asin', 12), ('Amazon link', 'LINK', 12)]

def sheet(ws, d):
    letters = {k: get_column_letter(j) for j, (_, k, _) in enumerate(COLS, 1)}
    for j, (h, _, w) in enumerate(COLS, 1):
        c = ws.cell(1, j, h); c.font = hdr; c.fill = fill; c.alignment = Alignment(vertical='center', wrap_text=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    for i, r in enumerate(d.itertuples(), 2):
        for j, (h, k, w) in enumerate(COLS, 1):
            if k == 'REV': v = '=%s%d*%s%d' % (letters['price'], i, letters['monthly_sales'], i)
            elif k == 'SCORE': v = '=ROUND(%s%d/SQRT(%s%d+20),1)' % (letters['monthly_sales'], i, letters['reviews'], i)
            elif k == 'LINK': v = '=HYPERLINK("https://www.%s/dp/%s","View")' % (DOM[r.market], r.asin)
            else:
                v = getattr(r, k)
                if isinstance(v, float) and (v != v or (k == 'weight_lb' and v < 0)): v = None
            c = ws.cell(i, j, v); c.font = Font(name=F, color='1F4FD6' if k == 'LINK' else '000000')
            if k == 'price': c.number_format = '"%s "#,##0.00' % CUR[r.market]
            if k == 'REV': c.number_format = '"%s "#,##0' % CUR[r.market]
        ws.cell(i, 1).fill = PatternFill('solid', fgColor=VF[r.verdict])
    ws.freeze_panes = 'D2'
    ws.auto_filter.ref = 'A1:%s%d' % (get_column_letter(len(COLS)), max(2, len(d) + 1))

ws0 = wb.active; ws0.title = 'Read me'
lines = []
if kind == 'niche':
    lines.append('Helium 10 Black Box: the niche of "%s", %s' % (phrase, date))
    lines.append('')
    lines.append('How: Black Box found the best-selling listings with these words, took their Amazon sub-category and searched its parent niche for products with room for a new seller.')
else:
    lines.append('Helium 10 Black Box: the niche with the biggest gap, %s' % date)
    lines.append('')
    lines.append('How: in every safe category, Black Box listed products that sell your target (AU 100+ a month, UAE 50+) in your price range. Each sub-niche was scored by how many of them still have few reviews (AU 230 or fewer, UAE 115 or fewer), times the share that do, times their middle sales. The top sub-niche was then searched for good products. Products shown in the last 21 days are left out.')
lines.append('')
for mk in ['AU', 'AE']:
    i = info.get(mk) or {}
    s = '%s: niche %s' % (CN[mk], i.get('niche') or 'not found')
    if i.get('ref'): s += '; your product here: "%s" (%s sales/mo, %s reviews)' % (i.get('ref'), i.get('refSales', '?'), i.get('refReviews', '?'))
    if i.get('note'): s += '; ' + i['note']
    if i.get('widened'): s += '; widened one level up because the niche was small'
    lines.append(s)
    for g in (i.get('gaps') or [])[:6]:
        lines.append('    gap candidate: %s (%s): %s well-selling products with few reviews, %s%% of sellers, middle sales %s/mo' % (g.get('name'), g.get('cat'), g.get('open'), g.get('share', '?'), g.get('med')))
lines += ['', 'Searches per niche: best sellers with few reviews, new listings (12 months or less), rivals rated 4.2 stars or lower, light items (2 lb or less), 50 reviews or fewer with 3 sellers or fewer. Consumables and big brands excluded.',
          'Good pick = AU 100+ sales and 230 reviews or fewer, UAE 100+ sales and 115 reviews or fewer, and nothing under Watch out. Check first = meets that but has a watch-out. Close = no watch-out, 50+ sales. Skip = the rest.',
          'Same niche = in the same Amazon sub-category as your product (or the gap sub-niche). Score = sales / square root of (reviews + 20). Helium 10 sales are estimates, often shared across variations; check page one before ordering.']
for n, t in enumerate(lines, 1):
    c = ws0.cell(n, 1, t); c.font = Font(name=F, bold=(n == 1), size=13 if n == 1 else 10)
ws0.column_dimensions['A'].width = 170
for mk in ['AU', 'AE']:
    d = df[df.market == mk].copy()
    if len(d):
        d['o'] = d.verdict.map(ORDER); d = d.sort_values(['o', 'score'], ascending=[True, False])
    sheet(wb.create_sheet('%s good picks' % CN[mk]), d[d.verdict == 'Good pick'] if len(d) else d)
    sheet(wb.create_sheet('%s all %d' % (CN[mk], len(d))), d)
wb.save('%s/%s' % (out, xname))

# ---- tab 2 documents ----
def row(r):
    t = re.sub(r'[|]', ' ', r.title)[:40]; b = re.sub(r'[|]', ' ', r.brand)[:10]
    fl = ('S' if 'consumable' in r.issues else '') + ('E' if 'electrical' in r.issues else '') + ('K' if 'kids' in r.issues else '')
    return '|'.join([t, b, '%.2f' % r.price, str(int(r.monthly_sales)), str(int(r.reviews)), '%.1f' % r.rating, str(int(r.sellers)), str(int(r.age_months)), r.asin, str(int(r.variations)), 'A' if r.amazon_sells == 'yes' else '', fl])
summary = {'id': rid, 'kind': kind, 'date': date, 'xlsx': xname}
for mk in ['AU', 'AE']:
    d = df[df.market == mk]
    i = info.get(mk) or {}
    niche = i.get('niche') or ''
    label = ('Niche of “%s”' % phrase if kind == 'niche' else 'Biggest gap: ' + leafname(mk)) + ' · ' + label_day
    doc = {'phrase': '', 'mode': 'explore', 'run': rid, 'kind': kind, 'label': label, 'of': phrase, 'niche': niche, 'leaf': i.get('leaf') or '', 'ref': i.get('ref') or '',
           'gaps': (i.get('gaps') or [])[:5], 'market': mk, 'status': 'done', 'requestedAt': at, 'doneAt': now, 'note': i.get('note') or '', 'file': shown_file}
    if not len(d):
        doc['status'] = 'error'; doc['note'] = (i.get('note') or 'Black Box found no products for this niche here')
    else:
        keep = d[d.verdict != 'Skip']
        same = keep[keep.same_niche == 'yes'].sort_values('score', ascending=False).head(15) if kind == 'niche' else keep.head(0)
        rest = keep[~keep.asin.isin(same.asin)]
        best = rest[rest.verdict.isin(['Good pick', 'Check first'])].sort_values('score', ascending=False).head(40)
        close = rest[rest.verdict == 'Close'].sort_values('score', ascending=False).head(max(10, 45 - len(best)))
        cat = niche or 'all safe categories'
        doc['ideas'] = {'at': now, 'mk': mk, 'state': 'ok', 'g': 'best', 'cat': cat, 'total': int(len(d)), 'rows': [row(r) for r in best.itertuples()]}
        doc['more'] = {'at': now, 'mk': mk, 'state': 'ok', 'g': 'close', 'cat': cat, 'total': int(len(d)), 'rows': [row(r) for r in close.itertuples()]}
        if len(same): doc['extra'] = {'at': now, 'mk': mk, 'state': 'ok', 'g': 'niche', 'cat': i.get('leaf') or cat, 'total': int(len(d)), 'rows': [row(r) for r in same.itertuples()]}
    json.dump(doc, open('%s/%s_doc.json' % (out, mk.lower()), 'w'), ensure_ascii=False)
    gp = d[d.verdict == 'Good pick'].sort_values('score', ascending=False)
    summary[mk] = {'niche': niche, 'products': int(len(d)), 'good_picks': int(len(gp)),
                   'top': ['%s (%s %.2f, %d/mo, %d reviews)' % (r.title[:45], CUR[mk], r.price, r.monthly_sales, r.reviews) for r in gp.head(3).itertuples()]}

# ---- tab 3 document: the scan as a Black Box-style export, per country ----
H = ['Product Title', 'ASIN', 'Brand', 'Category', 'Subcategory', 'Price', 'Monthly Sales', 'Monthly Revenue', 'Review Count', 'Reviews Rating', 'Sellers', 'Age Months', 'Variation Count', 'Fulfillment', 'Seller Country', 'Buy Box', 'Same Niche']
def csv_text(d):
    d = d.sort_values('score', ascending=False).head(400)
    rows = [H]
    for r in d.itertuples():
        rows.append([r.title[:110], r.asin, r.brand[:30], r.category, r.subcategory, '%.2f' % r.price, int(r.monthly_sales), int(r.monthly_revenue), int(r.reviews), r.rating, int(r.sellers), r.age_months, int(r.variations), r.fulfillment, r.seller_country, 'Amazon' if r.amazon_sells == 'yes' else '', r.same_niche])
    q = lambda v: (lambda s: '"' + s.replace('"', '""') + '"' if re.search(r'[",\n]', s) else s)(str(v))
    return '\n'.join(','.join(q(v) for v in x) for x in rows)
scan = {'run': rid, 'kind': kind, 'phrase': phrase, 'at': now, 'date': date, 'file': shown_file,
        'label': ('Niche of “%s”' % phrase if kind == 'niche' else 'Biggest gap') + ' · ' + label_day,
        'niche': {mk: (info.get(mk) or {}).get('niche') or '' for mk in ['AU', 'AE']}}
for mk in ['AU', 'AE']:
    scan[mk] = csv_text(df[df.market == mk])
json.dump(scan, open('%s/scan_doc.json' % out, 'w'), ensure_ascii=False)
summary['scan_doc_bytes'] = len(json.dumps(scan, ensure_ascii=False).encode())
print(json.dumps(summary, ensure_ascii=False))
