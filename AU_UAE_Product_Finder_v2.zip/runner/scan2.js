window.__pfScan = async (REQ) => {
REQ = Object.assign({}, REQ, { phrase: String(REQ.phrase || "").replace(/[^A-Za-z0-9 &+'-]/g, " ").slice(0, 60), kind: REQ.kind === "niche" ? "niche" : "gap", id: String(REQ.id || "x").replace(/[^A-Za-z0-9-]/g, "").slice(0, 40) });
const sleep = ms => new Promise(r => { const e = performance.now() + ms, c = new MessageChannel(); c.port1.onmessage = () => { if (performance.now() >= e) { c.port1.close(); r(); } else c.port2.postMessage(0); }; c.port2.postMessage(0); });
const until = async (f, ms) => { const e = Date.now() + ms; while (Date.now() < e) { const v = f(); if (v) return v; await sleep(150); } return f(); };
const q = id => document.querySelector('[data-testid="' + id + '"]');
await until(() => q('products-tabs-marketplace') || document.querySelector('input[type=password]'), 25000);
if (!q('products-tabs-marketplace')) return JSON.stringify({ state: document.querySelector('input[type=password]') || /log-?in|sign-?in|auth/i.test(location.href) ? 'logged_out' : 'error', note: 'Products page did not load' });
if (!window.__bp4) { const of = window.fetch; window.__bp4 = { o: null, f: of }; window.fetch = function (u, o) { try { const url = String(u && u.url || u); if (/^https:\/\/h10api\.pacvue\.com\/rta\/blackbox\/v1\//.test(url) && /[?&]accountId=/.test(url) && o && o.headers) window.__bp4.o = { url, headers: o.headers, credentials: o.credentials, mode: o.mode }; } catch (e) {} return of.apply(this, arguments); }; }
const fire = el => ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
if (!window.__bp4.o) { const sel = q('products-tabs-marketplace'); const dom = sel.innerText.trim() === 'www.amazon.com.au' ? 'amazon.com' : 'amazon.com.au'; fire(sel.firstElementChild || sel); const o = await until(() => [...document.querySelectorAll('[role=option]')].find(e => e.getAttribute('data-value') === dom), 4000); if (o) fire(o); await until(() => window.__bp4.o, 10000); }
if (!window.__bp4.o) return JSON.stringify({ state: 'error', note: 'Helium 10 data request not seen' });
/* daily safety limit: Helium 10 allows about 250 Black Box searches a day; this scanner stops at DAY_MAX so some are left for you */
const DAY_MAX = 200;
const usedToday = () => { try { const t = new Date().toISOString().slice(0, 10), u = JSON.parse(localStorage.getItem('pfUses1') || '{}'); return u.d === t ? +u.n || 0 : 0; } catch (e) { return 0; } };
const api = async (path, body) => { if (body && /search\/products$/.test(path) && usedToday() >= DAY_MAX) throw new Error('budget'); const A = window.__bp4.o, u = new URL(A.url); const url = u.origin + '/rta/blackbox/v1/' + path + (path.includes('?') ? '&' : '?') + 'accountId=' + u.searchParams.get('accountId'); const r = await window.__bp4.f.call(window, url, { method: body ? 'POST' : 'GET', headers: A.headers, credentials: A.credentials, mode: A.mode, body: body ? JSON.stringify(body) : undefined }); if (r.status === 401 || r.status === 403) throw new Error('login'); if (r.status === 402) throw new Error('limit'); if (body && /search\/products$/.test(path)) { try { const t = new Date().toISOString().slice(0, 10), u0 = JSON.parse(localStorage.getItem('pfUses1') || '{}'); const u1 = u0.d === t ? u0 : { d: t, n: 0 }; u1.n++; localStorage.setItem('pfUses1', JSON.stringify(u1)); } catch (e) {} } let j = null; try { j = await r.json(); } catch (e) {} return j; };
const search = async (mid, filters, pages) => { const s = await api('search/products', { filters, marketplaceId: mid, filtersType: 'advanced' }); const id = s && s.data && s.data.id; if (!id) return []; let rows = []; for (let p = 1; p <= (pages || 2); p++) { let j = null; for (let t = 0; t < 6; t++) { j = await api('search/products/' + id + '/results?page=' + p + '&per_page=100'); if (j && (j.data || /empty/i.test(String(j.message)))) break; await sleep(1500); } if (!j || !j.data) break; rows = rows.concat(j.data.tableData || []); if (!(j.meta && j.meta.last_page > p)) break; } return rows; };
const BAD = /select ?all|baby|beauty|book|clothing|fashion|computer|electronic|health|grocery|food|software|video ?game|toy|lighting|appliance|jewel|luggage|gift|music|movie|kindle|automotive|industrial/i;
const BADLEAF = /food|treat|snack|chew|flea|\bticks?\b|worm|supplement|vitamin|medic|litter$|shampoo|battery|batteries|charger|nappies|wipes|lotion|perfume|cleaning|detergent|refill|candle|sports fan|fan shop|replacement|filters?$|bulbs?|seeds|plants|soil|fertil|pesticide|insect|cookware sets|knives|bedding sets|sheet|duvet|quilt|towel|curtain|panels|rugs?$|frames|\b(shirts?|polos?|jackets?|clothing|apparel|shoes?|socks?|pants|shorts|dress(es)?|leggings|hoodies?|t-shirts?|costumes?|lamps?|lights?|lighting|electric\w*|heaters?|fans?|trackers?|fountains?|bidets?|children'?s?|kids|baby|watch(es)?|smart\w*)\b/i;
const EX = 'food, treats, snack, chews, flea, tick, wormer, supplement, vitamin, medicine, tablets, capsules, litter, shampoo, refill, battery, batteries, charger, usb, adapter, nappies, wipes, lotion, serum, perfume, christmas, halloween, advent';
const BX = 'Amazon Basics, Kmart, Anko, Philips, Samsung, Apple, Dyson, LEGO, Purina, Breville, Sunbeam, Tefal, Whiskas, Royal Canin';
const CFG = { AU: { mid: 14, pmin: 25, pmax: 70, smin: 100, rmax: 250, tS: 100, tR: 230, n: [15, 120, 30, 600] }, AE: { mid: 17, pmin: 60, pmax: 260, smin: 50, rmax: 150, tS: 50, tR: 115, n: [40, 450, 20, 400] } };
const units = r => (+r.childMonthlySales > 0 ? +r.childMonthlySales : +r.monthlySales > 0 ? +r.monthlySales : 0);
const leafOf = r => (r.subcategories || [])[0] || {};
const words = s => String(s || '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').split(' ').filter(w => w.length > 2 && !/^(for|with|and|the|set|pack|pcs)$/.test(w));
const sim = (a, b) => { const A = words(a), B = words(b); return A.filter(w => B.some(x => x.replace(/s$/, '') === w.replace(/s$/, ''))).length; };
const med = a => { a = a.filter(v => v > 0).sort((x, y) => x - y); return a.length ? a[Math.floor((a.length - 1) / 2)] : 0; };
window.__pf = window.__pf || {};
const P = window.__pf[REQ.id] = window.__pf[REQ.id] || { out: {}, info: {}, busy: {} };

if (REQ.step === 'save') {
  const H = ['market', 'title', 'brand', 'category', 'subcategory', 'price', 'monthly_sales', 'monthly_revenue', 'reviews', 'rating', 'sellers', 'age_months', 'variations', 'weight_lb', 'asin', 'amazon_sells', 'seller_country', 'fulfillment', 'found_by', 'same_niche'];
  const qv = v => { v = v == null ? '' : String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
  const lines = ['#info ' + JSON.stringify(P.info).replace(/[\r\n]+/g, ' '), H.join(',')];
  ['AU', 'AE'].forEach(mk => (P.out[mk] || []).forEach(r => { const s = units(r), p = (+r.price || 0) / 100; lines.push([mk, String(r.title || '').replace(/\s+/g, ' ').slice(0, 150), r.brand || '', r.categoryTitle || '', leafOf(r).nodeName || '', p.toFixed(2), s, Math.round(s * p), +r.reviewCount || 0, +r.reviewsRating || 0, +r.numberOfSellers || 0, +r.ageInMonths || 0, +r.variationCount || 0, +r.weight || '', r.asin, /^amazon/i.test(r.bbSeller || '') ? 'yes' : '', r.bbSellerCountry || '', r.sellerType || '', r.__g.join('+') + (r.__seen ? '+shown-before' : ''), r.__same ? 'yes' : ''].map(qv).join(',')); }));
  const d = new Date(), ds = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const file = 'H10_BlackBox_' + REQ.kind + '_' + String(REQ.id).replace(/[^A-Za-z0-9-]/g, '') + '.csv';
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv' })); a.download = file; document.body.appendChild(a); a.click();
  /* a slim copy for reading back as page text (when the Downloads folder can't be read): best 200 per country plus all same-niche rows */
  const score = r => units(r) / Math.sqrt((+r.reviewCount || 0) + 20);
  const slim = ['#info ' + JSON.stringify(P.info).replace(/[\r\n]+/g, ' '), H.join(',')];
  ['AU', 'AE'].forEach(mk => { const rs = (P.out[mk] || []).slice().sort((x, y) => score(y) - score(x)); rs.filter((r, i) => i < 200 || r.__same).forEach(r => { const s = units(r), p = (+r.price || 0) / 100; slim.push([mk, String(r.title || '').replace(/\s+/g, ' ').slice(0, 70), String(r.brand || '').slice(0, 20), r.categoryTitle || '', leafOf(r).nodeName || '', p.toFixed(2), s, Math.round(s * p), +r.reviewCount || 0, +r.reviewsRating || 0, +r.numberOfSellers || 0, +r.ageInMonths || 0, +r.variationCount || 0, +r.weight || '', r.asin, /^amazon/i.test(r.bbSeller || '') ? 'yes' : '', r.bbSellerCountry || '', r.sellerType || '', r.__g.join('+') + (r.__seen ? '+shown-before' : ''), r.__same ? 'yes' : ''].map(qv).join(',')); }); });
  P.slim = slim.join('\n'); P.chunks = []; for (let i = 0; i < P.slim.length; i += 24000) { let j = Math.min(P.slim.length, i + 24000); if (j < P.slim.length) { const nl = P.slim.lastIndexOf('\n', j); if (nl > i) j = nl + 1; } P.chunks.push(P.slim.slice(i, j)); i = j - 24000; }
  return JSON.stringify({ state: 'ok', file, date: ds, AU: (P.out.AU || []).length, AE: (P.out.AE || []).length, nicheAU: (P.info.AU || {}).niche || '', nicheAE: (P.info.AE || {}).niche || '', chunks: P.chunks.length });
}
/* step "text": show part n of the slim copy as the page's only text, for get_page_text */
if (REQ.step === 'text') {
  if (!P.chunks) return JSON.stringify({ state: 'error', note: 'run the save step first' });
  const n = Math.max(0, Math.min(P.chunks.length - 1, +REQ.n || 0));
  document.body.innerHTML = ''; const pre = document.createElement('pre'); pre.textContent = P.chunks[n]; document.body.appendChild(pre);
  return JSON.stringify({ state: 'ok', n, chunks: P.chunks.length, chars: P.chunks[n].length, firstLine: P.chunks[n].split('\n')[0].slice(0, 40) });
}

const mk = REQ.step, C = CFG[mk];
if (!C) return JSON.stringify({ state: 'error', note: 'bad step' });
const brief = () => JSON.stringify({ state: 'ok', step: mk, products: (P.out[mk] || []).length, niche: P.info[mk] && P.info[mk].niche, ref: P.info[mk] && P.info[mk].ref, cached: !!(P.info[mk] && P.info[mk].cachedAt), searchesToday: usedToday(), dayMax: DAY_MAX });
/* a niche scan of the same words is kept for 5 days, so asking again costs no searches; REQ.refresh = true forces a new scan */
const NC_KEY = 'pfNicheCache1', NC_DAYS = 5, NC_KEEP = 12;
const ncId = mk + '|' + String(REQ.phrase || '').toLowerCase().trim();
const KEEP = ['title', 'brand', 'categoryTitle', 'price', 'childMonthlySales', 'monthlySales', 'reviewCount', 'reviewsRating', 'numberOfSellers', 'ageInMonths', 'variationCount', 'weight', 'asin', 'parentAsin', 'bbSeller', 'bbSellerCountry', 'sellerType', '__g', '__same', '__seen'];
const slimRow = r => { const o = {}; KEEP.forEach(k => { if (r[k] != null) o[k] = r[k]; }); const l = leafOf(r); o.subcategories = [{ nodeId: l.nodeId, nodeName: l.nodeName }]; return o; };
const ncGet = () => { try { const c = JSON.parse(localStorage.getItem(NC_KEY) || '{}')[ncId]; return c && Date.now() - c.at < NC_DAYS * 864e5 ? c : null; } catch (e) { return null; } };
const ncPut = (info, out) => { try { const c = JSON.parse(localStorage.getItem(NC_KEY) || '{}'); c[ncId] = { at: Date.now(), info, out: out.map(slimRow) }; Object.keys(c).sort((a, b) => c[b].at - c[a].at).slice(NC_KEEP).forEach(k => delete c[k]); localStorage.setItem(NC_KEY, JSON.stringify(c)); } catch (e) {} };
if (REQ.kind === 'niche' && !REQ.refresh && !P.busy[mk]) { const c = ncGet(); if (c) { P.info[mk] = Object.assign({}, c.info, { cachedAt: c.at }); P.out[mk] = c.out; return brief(); } }
if (P.out[mk]) return brief();
const work = async () => {
  const mid = C.mid, tops = ((await api('categories?marketplaceId=' + mid)) || {}).data || [], safe = tops.filter(c => !BAD.test(c.nodeName));
  const kidCache = {};
  const kids = async id => kidCache[id] || (kidCache[id] = (((await api('categories/' + id + '/children?marketplaceId=' + mid)) || {}).data || []));
  /* find the path top > ... > node, by Amazon node id or by name; children closest to the hint are opened first */
  const findPath = async (top, test, hint) => {
    let queue = [[top]], calls = 0;
    while (queue.length && calls < 90) {
      queue.sort((a, b) => sim(b[b.length - 1].nodeName, hint) - sim(a[a.length - 1].nodeName, hint) || a.length - b.length);
      const path = queue.shift(), ch = await kids(path[path.length - 1].id); calls++;
      for (const c of ch) { if (test(c)) return path.concat(c); if (c.hasChildren) queue.push(path.concat(c)); }
    }
    return null;
  };
  const nicheOf = path => path && path.length >= 3 ? path.slice(0, path.length - 1) : path;
  const info = { kind: REQ.kind, phrase: REQ.phrase || '' };
  let niche = null, leafId = null, leafName = '';
  if (REQ.kind === 'niche') {
    const w = words(REQ.phrase), tries = [];
    /* a compound typed with a space ("silver fish trap") is tried joined first ("silverfish trap"), else it matches the wrong products */
    for (let i = 0; i < w.length - 1 && tries.length < 2; i++) { const j = w[i] + w[i + 1]; if (w[i].length >= 3 && w[i + 1].length >= 3 && j.length <= 12) tries.push(w.slice(0, i).concat([j], w.slice(i + 2)).join(' ')); }
    tries.push(w.join(' '));
    if (w.length > 2) tries.push(w.slice(-2).join(' '));
    /* the second country follows the words that worked in the first; if nothing matches there, the same niche is found by name */
    const firstInfo = mk !== 'AU' && window.__pf[REQ.id].info.AU;
    if (firstInfo && firstInfo.matched) tries.splice(0, tries.length, firstInfo.matched);
    let refRows = [];
    for (const t of tries) { if (!t) continue; refRows = (await search(mid, { titleIncludeKeyword: t, monthlySalesFrom: 5 }, 1)).filter(r => leafOf(r).nodeId); if (refRows.length >= (t.split(' ').length < w.length && !firstInfo ? 3 : 1)) { info.matched = t; break; } }
    if (refRows.length) {
      refRows.sort((a, b) => units(b) - units(a));
      const votes = {};
      refRows.slice(0, 12).forEach(r => { const l = leafOf(r), k = r.categoryTitle + '|' + l.nodeId; votes[k] = votes[k] || { s: 0, cat: r.categoryTitle, l: l, r: r }; votes[k].s += units(r) + 1; });
      const best = Object.values(votes).sort((a, b) => b.s - a.s)[0];
      const top = tops.find(c => c.nodeName === best.cat) || tops.sort((a, b) => sim(b.nodeName, best.cat) - sim(a.nodeName, best.cat))[0];
      leafId = best.l.nodeId; leafName = best.l.nodeName; info.ref = String(best.r.title || '').slice(0, 80); info.refSales = units(best.r); info.refReviews = +best.r.reviewCount || 0;
      const path = top ? await findPath(top, c => c.nodeId === leafId, leafName + ' ' + REQ.phrase) : null;
      niche = nicheOf(path) || (top ? [top] : null);
    } else if (window.__pf[REQ.id].info.AU && window.__pf[REQ.id].info.AU.nicheNames) {
      /* nothing like it in this country: look for the same niche by name */
      const names = window.__pf[REQ.id].info.AU.nicheNames, top = safe.slice().sort((a, b) => sim(b.nodeName, names[0]) - sim(a.nodeName, names[0]) || sim(b.nodeName, REQ.phrase) - sim(a.nodeName, REQ.phrase))[0];
      const want = names[names.length - 1].toLowerCase();
      const path = top ? await findPath(top, c => c.nodeName.toLowerCase() === want, names.join(' ') + ' ' + REQ.phrase) : null;
      niche = path || (top ? [top] : null); info.ref = ''; info.note = 'no listing with these words here, same niche by name';
    }
    if (!niche) return { state: 'error', note: 'no products found for “' + REQ.phrase + '” in this country' };
  } else {
    /* biggest gap: in every safe category, products selling at least the target; per sub-niche count the ones with few reviews */
    /* the gap ranking costs one Black Box search per category, so it is kept for 7 days (Helium 10 allows 250 searches a day) */
    let ranked = null;
    try { const gc = JSON.parse(localStorage.getItem('pfGapCache1') || '{}')[mk]; if (gc && Date.now() - gc.at < 7 * 864e5 && gc.ranked && gc.ranked.length) { ranked = gc.ranked; info.gapCached = gc.at; } } catch (e) {}
    if (!ranked) {
      const leaves = {};
      const leafRec = (top, l) => leaves[l.nodeId] = leaves[l.nodeId] || { id: l.nodeId, name: l.nodeName, top: { id: top.id, nodeName: top.nodeName }, n: 0, o1: 0, open: 0, s: [], w: [], b: {} };
      for (const top of safe) {
        const f = { category: [String(top.id)], priceFrom: C.pmin * 100, priceTo: C.pmax * 100, monthlySalesFrom: C.tS, titleExcludeKeyword: EX, brandExclude: BX };
        const allRows = await search(mid, f, 2), s1 = {};
        allRows.forEach(r => { const l = leafOf(r), pa = r.parentAsin || r.asin; if (!l.nodeId || BADLEAF.test(l.nodeName) || s1[pa]) return; s1[pa] = 1; const o = leafRec(top, l); o.n++; if ((+r.reviewCount || 0) <= C.tR) { o.o1++; o.open++; o.s.push(units(r)); o.w.push(+r.weight || 0); o.b[String(r.brand || '').toLowerCase()] = 1; } });
      }
      const minOpen = mk === 'AE' ? 2 : 3; /* the UAE market is smaller */
      ranked = Object.values(leaves).filter(o => o.open >= minOpen && Object.keys(o.b).length >= minOpen && med(o.w) <= 8).map(o => ({ id: o.id, name: o.name, top: o.top, open: o.open, share: o.n >= 3 ? o.o1 / o.n : 0.5, med: med(o.s) })).map(o => Object.assign(o, { score: o.open * o.share * o.med })).sort((a, b) => b.score - a.score).slice(0, 12);
      if (ranked.length) { try { const gc = JSON.parse(localStorage.getItem('pfGapCache1') || '{}'); gc[mk] = { at: Date.now(), ranked }; localStorage.setItem('pfGapCache1', JSON.stringify(gc)); } catch (e) {} }
    }
    if (!ranked.length) return { state: 'error', note: 'no category with enough selling products' };
    /* skip gap niches this Chrome already searched in the last 3 days, so each press gives a new niche */
    let doneG = {}; try { doneG = JSON.parse(localStorage.getItem('pfGapDone1') || '{}'); } catch (e) {}
    const fresh = ranked.filter(o => !(doneG[mk + o.id] && Date.now() - doneG[mk + o.id] < 3 * 864e5));
    const order = (fresh.length ? fresh : ranked);
    info.gaps = order.slice(0, 6).map(o => ({ name: o.name, cat: o.top.nodeName, open: o.open, share: Math.round(o.share * 100), med: o.med }));
    info.cands = order.slice(0, 2); /* at most 2 niches tried per press, to save searches */
  }
  const mem = (() => { try { const m = JSON.parse(localStorage.getItem('pfFinderMem1') || '{}') || {}; m.s = m.s || {}; m.k = m.k || {}; return m; } catch (e) { return { s: {}, k: {} }; } })();
  Object.keys(mem.s).forEach(m => Object.keys(mem.s[m]).forEach(a => { if (Date.now() - mem.s[m][a] > 21 * 864e5) delete mem.s[m][a]; }));
  const seen = mem.s[mk] = mem.s[mk] || {}, useMem = REQ.kind === 'gap';
  const base = REQ.kind === 'niche' ? { priceFrom: C.n[0] * 100, priceTo: C.n[1] * 100, monthlySalesFrom: C.n[2], reviewCountTo: C.n[3], titleExcludeKeyword: EX, brandExclude: BX } :
    { priceFrom: C.pmin * 100, priceTo: C.pmax * 100, monthlySalesFrom: Math.round(C.smin / 2), reviewCountTo: C.rmax * 2, titleExcludeKeyword: EX, brandExclude: BX };
  /* one broad search per niche level; the old four searches (best / new / fix / few) are now tags worked out from each row */
const groupsOf = r => { const g = ['best'], age = +r.ageInMonths || 0, rv = +r.reviewCount || 0, rt = +r.reviewsRating || 0, sl = +r.numberOfSellers || 0; if (age > 0 && age <= 12) g.push('new'); if (rt > 0 && rt <= 4.2 && rv >= 5) g.push('fix'); if (rv <= 50 && sl > 0 && sl <= 3) g.push('few'); return g; };
  let all = {}, old = {}, skipped = 0, lvl = 0;
  /* the niche search; a gap run tries the next-biggest gap when the first one has (almost) only products shown before */
  const cands = REQ.kind === 'gap' ? info.cands : [null];
  delete info.cands;
  for (let ci = 0; ci < cands.length; ci++) {
    if (cands[ci]) { const g = cands[ci]; leafId = g.id; leafName = g.name; const path = await findPath(g.top, c => c.nodeId === leafId, g.name); niche = nicheOf(path) || [g.top]; }
    lvl = niche.length;
    while (true) {
      const node = niche[lvl - 1]; base.category = [String(node.id)]; all = {}; old = {}; skipped = 0;
      { const rows = await search(mid, Object.assign({}, base), 3); rows.forEach(r => { const k = r.parentAsin || r.asin, gs = groupsOf(r); if (useMem && (seen[k] || seen[r.asin])) { skipped++; if (!old[k]) old[k] = Object.assign(r, { __g: gs, __same: leafOf(r).nodeId === leafId, __seen: 1 }); return; } if (!all[k]) all[k] = Object.assign(r, { __g: [], __same: leafOf(r).nodeId === leafId }); gs.forEach(g => { if (all[k].__g.indexOf(g) < 0) all[k].__g.push(g); }); }); }
      if (Object.keys(all).length >= 25 || lvl <= 2 || lvl < niche.length) break;
      lvl--; /* too few products in this niche: go one level up, never more than once */
    }
    if (Object.keys(all).length >= 20) break;
  }
  /* almost everything was shown before: show the best of those again (marked) rather than nothing */
  if (Object.keys(all).length < 12) { const units0 = r => units(r) / Math.sqrt((+r.reviewCount || 0) + 20); Object.values(old).sort((a, b) => units0(b) - units0(a)).slice(0, 40 - Object.keys(all).length).forEach(r => { all[r.parentAsin || r.asin] = r; }); info.reshown = true; }
  if (REQ.kind === 'gap' && leafId) { try { const dg = JSON.parse(localStorage.getItem('pfGapDone1') || '{}'); dg[mk + leafId] = Date.now(); localStorage.setItem('pfGapDone1', JSON.stringify(dg)); } catch (e) {} }
  if (lvl < niche.length) { niche = niche.slice(0, lvl); info.widened = true; }
  info.niche = niche.map(c => c.nodeName).join(' › '); info.nicheNames = niche.map(c => c.nodeName); info.nicheId = niche[niche.length - 1].id; info.leaf = leafName;
  const out = Object.values(all);
  if (useMem) { out.forEach(r => { seen[r.asin] = Date.now(); if (r.parentAsin) seen[r.parentAsin] = Date.now(); }); try { localStorage.setItem('pfFinderMem1', JSON.stringify(mem)); } catch (e) {} }
  info.products = out.length; info.sameNiche = out.filter(r => r.__same).length; info.alreadyShown = skipped;
  P.info[mk] = info; P.out[mk] = out;
  if (REQ.kind === 'niche' && out.length) ncPut(info, out);
  return null;
};
/* long work runs on in the page; each call waits up to 35 s, then says "working" so the caller asks again */
P.res = P.res || {};
if (!P.busy[mk]) { P.res[mk] = null; P.busy[mk] = work().then(r => { P.res[mk] = r; P.busy[mk] = null; }, e => { P.res[mk] = { state: /login/.test(String(e)) ? 'logged_out' : /limit/.test(String(e)) ? 'limit' : /budget/.test(String(e)) ? 'limit' : 'error', note: /budget/.test(String(e)) ? 'Stopped at the daily safety limit (' + DAY_MAX + ' Black Box searches today). Try again tomorrow.' : String(e).slice(0, 80), searchesToday: usedToday(), dayMax: DAY_MAX }; P.busy[mk] = null; }); }
const end = Date.now() + 35000;
while (P.busy[mk] && Date.now() < end) await sleep(500);
if (P.busy[mk]) return JSON.stringify({ state: 'working', step: mk, note: 'still searching, run the same call again' });
if (P.res[mk]) return JSON.stringify(P.res[mk]);
return brief();
};
await window.__pfScan(__REQ__);
